package com.standard.envvalidator.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class ValidatorUtil {

	public static final Logger logger = LogManager.getLogger(ValidatorUtil.class);

	/**
	 * 
	 * @param jndiName
	 * @return
	 * @throws  
	 */
	public boolean validateDatasource (String jndiName) {

		logger.info("Start ValidatorUtil for jndi " + jndiName);
		java.sql.Connection con = null;
		try {
			Context initialContext = new InitialContext();
			DataSource ds = (DataSource)initialContext.lookup(jndiName);
			con = ds.getConnection();
			logger.info("Datasource successfully created");
			return true;
		}
		catch (Exception ex) {
			logger.error(ex);
			return false;
		}
		finally {
			try {
				con.close();
			}
			catch (Exception ignore) {

			}
		}

	}
	/**
	 * 
	 * @param jndiName
	 * @return
	 */
	public boolean validateMQ (String connectionFactoryJndi, String sendQJndi, String receiveQJndi) {
		Connection qConn = null;
		Session session = null;
		try {
			JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
			jndiObjectFactoryBean.setJndiName(connectionFactoryJndi);
			jndiObjectFactoryBean.afterPropertiesSet();
			ConnectionFactory connectionFactory = (ConnectionFactory)jndiObjectFactoryBean.getObject();
			qConn = connectionFactory.createConnection();
			session = qConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			qConn.start();
			jndiObjectFactoryBean = new JndiObjectFactoryBean();
			jndiObjectFactoryBean.setJndiName(sendQJndi);
			jndiObjectFactoryBean.afterPropertiesSet();
			Destination sendQ = (Destination)jndiObjectFactoryBean.getObject();

			MessageProducer sender = session.createProducer(sendQ);

			jndiObjectFactoryBean = new JndiObjectFactoryBean();
			jndiObjectFactoryBean.setJndiName(receiveQJndi);
			jndiObjectFactoryBean.afterPropertiesSet();
			Destination receiveQ = (Destination)jndiObjectFactoryBean.getObject();

			MessageConsumer receiver = session.createConsumer(receiveQ);

			return true;
		}
		catch (Exception ex) {
			logger.error(ex);
			return false;
		}
		finally {
			try {
				session.close();
				qConn.close();
			}
			catch(Exception ignore) {

			}
		}
	}
	/**
	 * 
	 * @param urlStr
	 * @param request
	 * @param xpathToCheck
	 * @param user
	 * @param password
	 * @return
	 * @throws IOException 
	 */
	public boolean validateWebservice(String urlStr, String request, String serviceFaultXPath, String user, String password, boolean webServiceBasicAuth, boolean webBypassClientCert) {
		//Code to make a webservice HTTP request
		
		try {
			String responseString = "";
			String outputString = "";

			URL url = new URL(urlStr);
			TrustManager[] trustAllCerts = new TrustManager[]{
					new X509TrustManager() {
						public java.security.cert.X509Certificate[] getAcceptedIssuers() {
							return null;
						}
						public void checkClientTrusted(
								java.security.cert.X509Certificate[] certs, String authType) {
						}
						public void checkServerTrusted(
								java.security.cert.X509Certificate[] certs, String authType) {
						}
					}
			};
			request = request.replace("{{u}}", user);
			request = request.replace("{{p}}", password);

			if (webBypassClientCert) {
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			}
			
			URLConnection connection = url.openConnection();
			HttpURLConnection httpConn = (HttpURLConnection)connection;
			
			if (webServiceBasicAuth) {
				String encoded = Base64.getEncoder().encodeToString((user+":"+password).getBytes(StandardCharsets.UTF_8));
				connection.setRequestProperty("Authorization", "Basic "+encoded);
			}
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			
			
			
			byte[] buffer = new byte[request.length()];
			buffer = request.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			// Set the appropriate HTTP parameters.
			httpConn.setRequestProperty("Content-Length",
					String.valueOf(b.length));
			httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
			httpConn.setRequestProperty("SOAPAction", urlStr);
			//httpConn.setRequestMethod("POST");
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true); 
			OutputStream out = httpConn.getOutputStream();

			//Write the content of the request to the outputstream of the HTTP Connection.
			out.write(b);
			out.close();
			//Ready with sending the request.

			//Read the response.
			if (httpConn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConn.getResponseCode());
			}

			InputStreamReader isr =
					new InputStreamReader(httpConn.getInputStream());
			BufferedReader in = new BufferedReader(isr);

			//Write the SOAP message response to a String.
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			
			if (serviceFaultXPath != null && !serviceFaultXPath.trim().isEmpty()) {
				
				DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		        Document doc = builder.parse(new ByteArrayInputStream(outputString.getBytes()));
		        XPath xpath = XPathFactory.newInstance().newXPath();
		        NodeList result = (NodeList)xpath.compile(serviceFaultXPath).evaluate(doc, XPathConstants.NODESET);
		        return result.getLength() == 0;
		        
			}
			else {
				return true;
			}
		}
		catch(Exception ex) {
			logger.error(ex);
			return false;
		}
	}
	public boolean validateRestService(String urlStr, String request, String user, String password, boolean restServiceBasicAuth, 
			boolean restBypassClientCert, String restServiceFaultPath, String responseType, Map<String, List<String>> requestHeader) {
		try {
			String responseString = "";
			String outputString = "";

			URL url = new URL(urlStr);
			TrustManager[] trustAllCerts = new TrustManager[]{
					new X509TrustManager() {
						public java.security.cert.X509Certificate[] getAcceptedIssuers() {
							return null;
						}
						public void checkClientTrusted(
								java.security.cert.X509Certificate[] certs, String authType) {
						}
						public void checkServerTrusted(
								java.security.cert.X509Certificate[] certs, String authType) {
						}
					}
			};
			
			if (restBypassClientCert) {
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			}
			URLConnection connection = url.openConnection();
			HttpURLConnection httpConn = (HttpURLConnection)connection;
			
			if (restServiceBasicAuth) {
				String encoded = Base64.getEncoder().encodeToString((user+":"+password).getBytes(StandardCharsets.UTF_8));
				connection.setRequestProperty("Authorization", "Basic "+encoded);
			}
						
			
			
			for (Map.Entry<String, List<String>> oneHeader : requestHeader.entrySet()) {
				String headerName = oneHeader.getKey();
				List<String> headerValues = oneHeader.getValue();
				
				for (String headerValue : headerValues) {
					httpConn.addRequestProperty(headerName,headerValue);
				}
			}
			
			
			if (request != null && !request.trim().isEmpty()) {
				
				request = request.replace("{{u}}", user);
				request = request.replace("{{p}}", password);
				ByteArrayOutputStream bout = new ByteArrayOutputStream();
				
				byte[] buffer = new byte[request.length()];
				buffer = request.getBytes();
				bout.write(buffer);
				byte[] b = bout.toByteArray();
				httpConn.setRequestProperty("Content-Length",
						String.valueOf(b.length));
				
				httpConn.setDoOutput(true);
				httpConn.setDoInput(true);
				OutputStream out = httpConn.getOutputStream();
				out.write(b);
				out.close();
			} 
			//Read the response.
			if (httpConn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConn.getResponseCode());
			}
			
			InputStreamReader isr =
					new InputStreamReader(httpConn.getInputStream());
			BufferedReader in = new BufferedReader(isr);

			
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			logger.info("REST Service Response ::\n" + outputString + "\n");
			if (responseType.equals("JSON") && restServiceFaultPath != null &&  ! restServiceFaultPath.trim().isEmpty()) {
				DocumentContext docCtx = JsonPath.parse(outputString);
				JsonPath jsonPath = JsonPath.compile(restServiceFaultPath);
				JSONArray val1=docCtx.read(jsonPath);

				return val1 == null || val1.length() == 0;
			}
			else if (responseType.equals("XML") && restServiceFaultPath != null &&  ! restServiceFaultPath.trim().isEmpty()) {
				DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		        Document doc = builder.parse(new ByteArrayInputStream(outputString.getBytes()));
		        XPath xpath = XPathFactory.newInstance().newXPath();
		        NodeList result = (NodeList)xpath.compile(restServiceFaultPath).evaluate(doc, XPathConstants.NODESET);
		        return result.getLength() == 0;
			}
			else {
				return true;
			}
		}
		catch(Exception ex) {
			logger.error(ex);
			return false;
		}
	}
}
