/**
 * 
 */
package com.standard.envvalidator.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.standard.envvalidator.controller.EnvValidatorController;

/**
 * @author s004538
 *
 */
public class ValidatorException extends RuntimeException {
	public static final Logger logger = LogManager.getLogger(EnvValidatorController.class);
	private String exceptionMsg;

	public ValidatorException(String exceptionMsg) {
		super(exceptionMsg);
		this.exceptionMsg = exceptionMsg;
		logger.error("Error on page:: " + exceptionMsg);
	}
	public String getExceptionMsg(){
		return this.exceptionMsg;
	}
	public void setExceptionMsg(String exceptionMsg) {
		logger.error("Error on page:: " + exceptionMsg);
		this.exceptionMsg = exceptionMsg;
	}
}
