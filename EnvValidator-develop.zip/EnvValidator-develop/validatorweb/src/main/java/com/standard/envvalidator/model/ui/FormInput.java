package com.standard.envvalidator.model.ui;

import java.util.List;
import java.util.Map;

public class FormInput {
	
	private boolean dbCheck;
	private boolean mqCheck;
	private boolean webServiceCheck;
	private boolean restServiceCheck;
	private String dbJndi;
	private String connectionFactoryJndi;
	private String sendQJndi;
	private String receiveQJndi;
	private String webServiceUrl;
	private String webServiceReq;
	private String serviceFaultXPath;
	private String webServiceUser;
	private String webServicePassword;
	private String restServiceUrl;
	private String restServiceReq;
	private String restServiceFaultPath;
	private String restServiceUser;
	private String restServicePassword;
	private boolean webServiceBasicAuth;
	private boolean webBypassClientCert;
	private boolean restServiceBasicAuth;
	private boolean restBypassClientCert;
	private String responseType;
	private Map<String, List<String>> requestHeader;
	
	/**
	 * @return the dbCheck
	 */
	public boolean isDbCheck() {
		return dbCheck;
	}
	/**
	 * @param dbCheck the dbCheck to set
	 */
	public void setDbCheck(boolean dbCheck) {
		this.dbCheck = dbCheck;
	}
	/**
	 * @return the mqCheck
	 */
	public boolean isMqCheck() {
		return mqCheck;
	}
	/**
	 * @param mqCheck the mqCheck to set
	 */
	public void setMqCheck(boolean mqCheck) {
		this.mqCheck = mqCheck;
	}
	/**
	 * @return the webServiceCheck
	 */
	public boolean isWebServiceCheck() {
		return webServiceCheck;
	}
	/**
	 * @param webServiceCheck the webServiceCheck to set
	 */
	public void setWebServiceCheck(boolean webServiceCheck) {
		this.webServiceCheck = webServiceCheck;
	}
	/**
	 * @return the restServiceCheck
	 */
	public boolean isRestServiceCheck() {
		return restServiceCheck;
	}
	/**
	 * @param restServiceCheck the restServiceCheck to set
	 */
	public void setRestServiceCheck(boolean restServiceCheck) {
		this.restServiceCheck = restServiceCheck;
	}
	/**
	 * @return the dbJndi
	 */
	public String getDbJndi() {
		return dbJndi;
	}
	/**
	 * @param dbJndi the dbJndi to set
	 */
	public void setDbJndi(String dbJndi) {
		this.dbJndi = dbJndi;
	}
	/**
	 * @return the connectionFactoryJndi
	 */
	public String getConnectionFactoryJndi() {
		return connectionFactoryJndi;
	}
	/**
	 * @param connectionFactoryJndi the connectionFactoryJndi to set
	 */
	public void setConnectionFactoryJndi(String connectionFactoryJndi) {
		this.connectionFactoryJndi = connectionFactoryJndi;
	}
	/**
	 * @return the sendQJndi
	 */
	public String getSendQJndi() {
		return sendQJndi;
	}
	/**
	 * @param sendQJndi the sendQJndi to set
	 */
	public void setSendQJndi(String sendQJndi) {
		this.sendQJndi = sendQJndi;
	}
	/**
	 * @return the receiveQJndi
	 */
	public String getReceiveQJndi() {
		return receiveQJndi;
	}
	/**
	 * @param receiveQJndi the receiveQJndi to set
	 */
	public void setReceiveQJndi(String receiveQJndi) {
		this.receiveQJndi = receiveQJndi;
	}
	/**
	 * @return the webServiceUrl
	 */
	public String getWebServiceUrl() {
		return webServiceUrl;
	}
	/**
	 * @param webServiceUrl the webServiceUrl to set
	 */
	public void setWebServiceUrl(String webServiceUrl) {
		this.webServiceUrl = webServiceUrl;
	}
	/**
	 * @return the webServiceReq
	 */
	public String getWebServiceReq() {
		return webServiceReq;
	}
	/**
	 * @param webServiceReq the webServiceReq to set
	 */
	public void setWebServiceReq(String webServiceReq) {
		this.webServiceReq = webServiceReq;
	}
	
	/**
	 * @return the serviceFaultXPath
	 */
	public String getServiceFaultXPath() {
		return serviceFaultXPath;
	}
	/**
	 * @param serviceFaultXPath the serviceFaultXPath to set
	 */
	public void setServiceFaultXPath(String serviceFaultXPath) {
		this.serviceFaultXPath = serviceFaultXPath;
	}
	/**
	 * @return the webServiceUser
	 */
	public String getWebServiceUser() {
		return webServiceUser;
	}
	/**
	 * @param webServiceUser the webServiceUser to set
	 */
	public void setWebServiceUser(String webServiceUser) {
		this.webServiceUser = webServiceUser;
	}
	/**
	 * @return the webServicePassword
	 */
	public String getWebServicePassword() {
		return webServicePassword;
	}
	/**
	 * @param webServicePassword the webServicePassword to set
	 */
	public void setWebServicePassword(String webServicePassword) {
		this.webServicePassword = webServicePassword;
	}
	/**
	 * @return the restServiceUrl
	 */
	public String getRestServiceUrl() {
		return restServiceUrl;
	}
	/**
	 * @param restServiceUrl the restServiceUrl to set
	 */
	public void setRestServiceUrl(String restServiceUrl) {
		this.restServiceUrl = restServiceUrl;
	}
	/**
	 * @return the restServiceReq
	 */
	public String getRestServiceReq() {
		return restServiceReq;
	}
	/**
	 * @param restServiceReq the restServiceReq to set
	 */
	public void setRestServiceReq(String restServiceReq) {
		this.restServiceReq = restServiceReq;
	}
	
	
	/**
	 * @return the restServiceFaultPath
	 */
	public String getRestServiceFaultPath() {
		return restServiceFaultPath;
	}
	/**
	 * @param restServiceFaultPath the restServiceFaultPath to set
	 */
	public void setRestServiceFaultPath(String restServiceFaultPath) {
		this.restServiceFaultPath = restServiceFaultPath;
	}
	/**
	 * @return the responseType
	 */
	public String getResponseType() {
		return responseType;
	}
	/**
	 * @param responseType the responseType to set
	 */
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
	/**
	 * @return the restServiceUser
	 */
	public String getRestServiceUser() {
		return restServiceUser;
	}
	/**
	 * @param restServiceUser the restServiceUser to set
	 */
	public void setRestServiceUser(String restServiceUser) {
		this.restServiceUser = restServiceUser;
	}
	/**
	 * @return the restServicePassword
	 */
	public String getRestServicePassword() {
		return restServicePassword;
	}
	/**
	 * @param restServicePassword the restServicePassword to set
	 */
	public void setRestServicePassword(String restServicePassword) {
		this.restServicePassword = restServicePassword;
	}
	/**
	 * @return the webServiceBasicAuth
	 */
	public boolean isWebServiceBasicAuth() {
		return webServiceBasicAuth;
	}
	/**
	 * @param webServiceBasicAuth the webServiceBasicAuth to set
	 */
	public void setWebServiceBasicAuth(boolean webServiceBasicAuth) {
		this.webServiceBasicAuth = webServiceBasicAuth;
	}
	/**
	 * @return the webBypassClientCert
	 */
	public boolean isWebBypassClientCert() {
		return webBypassClientCert;
	}
	/**
	 * @param webBypassClientCert the webBypassClientCert to set
	 */
	public void setWebBypassClientCert(boolean webBypassClientCert) {
		this.webBypassClientCert = webBypassClientCert;
	}
	/**
	 * @return the restServiceBasicAuth
	 */
	public boolean isRestServiceBasicAuth() {
		return restServiceBasicAuth;
	}
	/**
	 * @param restServiceBasicAuth the restServiceBasicAuth to set
	 */
	public void setRestServiceBasicAuth(boolean restServiceBasicAuth) {
		this.restServiceBasicAuth = restServiceBasicAuth;
	}
	/**
	 * @return the restBypassClientCert
	 */
	public boolean isRestBypassClientCert() {
		return restBypassClientCert;
	}
	/**
	 * @param restBypassClientCert the restBypassClientCert to set
	 */
	public void setRestBypassClientCert(boolean restBypassClientCert) {
		this.restBypassClientCert = restBypassClientCert;
	}
	/**
	 * @return the requestHeader
	 */
	public Map<String, List<String>> getRequestHeader() {
		return requestHeader;
	}
	/**
	 * @param requestHeader the requestHeader to set
	 */
	public void setRequestHeader(Map<String, List<String>> requestHeader) {
		this.requestHeader = requestHeader;
	}
	
}
