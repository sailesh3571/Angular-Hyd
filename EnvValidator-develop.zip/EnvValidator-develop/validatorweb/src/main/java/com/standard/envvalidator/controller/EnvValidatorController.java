/**
 * 
 */
package com.standard.envvalidator.controller;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.standard.envvalidator.model.ui.FormInput;
import com.standard.envvalidator.model.ui.ValidationResponse;
import com.standard.envvalidator.util.ValidatorUtil;

/**
 * @author s004538
 *
 */
@Controller
@RequestMapping("/view")
public class EnvValidatorController {
	
	public static final Logger logger = LogManager.getLogger(EnvValidatorController.class);
	
	@Autowired
	private ValidatorUtil validatorUtil;
	
	@RequestMapping(value = "/openForm", method = RequestMethod.GET)
	public String openForm(HttpSession session) {
		logger.info("Start view page");
		return "../validate.html";
	}
	
	@RequestMapping(value = "/processForm", method = RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String processForm(@RequestBody FormInput formInput ) throws IOException {
		logger.info("Start processing validation");
		ValidationResponse resp = new ValidationResponse();
		//Database
		if (formInput.isDbCheck() && validatorUtil.validateDatasource(formInput.getDbJndi())) {
			resp.setDbSuccess(true);
		}
		//MQ
		if (formInput.isMqCheck() && validatorUtil.validateMQ(formInput.getConnectionFactoryJndi(), formInput.getSendQJndi(), formInput.getReceiveQJndi())) {
			resp.setMqSuccess(true);
		}
		
		//WebService 
		if (formInput.isWebServiceCheck() && validatorUtil.validateWebservice(formInput.getWebServiceUrl(), 
				formInput.getWebServiceReq(), formInput.getServiceFaultXPath(), formInput.getWebServiceUser(), 
					formInput.getWebServicePassword(), formInput.isWebServiceBasicAuth(), formInput.isWebBypassClientCert())) {
			resp.setWebServiceSuccess(true);
		}
		if (formInput.isRestServiceCheck() && validatorUtil.validateRestService(formInput.getRestServiceUrl(), 
				formInput.getRestServiceReq(), formInput.getRestServiceUser(), 
					formInput.getRestServicePassword(), formInput.isRestServiceBasicAuth(), formInput.isRestBypassClientCert(), formInput.getRestServiceFaultPath(), formInput.getResponseType(),
					formInput.getRequestHeader())) {
			resp.setRestServiceSuccess(true);
		}
		//rest service
		
		
		//resp.setMqSuccess(true);
		String jsonStr = new JSONObject(resp).toString();
		return jsonStr;
	}
}
