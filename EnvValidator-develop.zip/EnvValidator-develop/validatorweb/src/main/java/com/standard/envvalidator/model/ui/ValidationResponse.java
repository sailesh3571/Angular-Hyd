package com.standard.envvalidator.model.ui;

public class ValidationResponse {
	private boolean dbSuccess;
	private boolean mqSuccess;
	private boolean webServiceSuccess;
	private boolean restServiceSuccess;
	/**
	 * @return the dbSuccess
	 */
	public boolean isDbSuccess() {
		return dbSuccess;
	}
	/**
	 * @param dbSuccess the dbSuccess to set
	 */
	public void setDbSuccess(boolean dbSuccess) {
		this.dbSuccess = dbSuccess;
	}
	/**
	 * @return the mqSuccess
	 */
	public boolean isMqSuccess() {
		return mqSuccess;
	}
	/**
	 * @param mqSuccess the mqSuccess to set
	 */
	public void setMqSuccess(boolean mqSuccess) {
		this.mqSuccess = mqSuccess;
	}
	/**
	 * @return the webServiceSuccess
	 */
	public boolean isWebServiceSuccess() {
		return webServiceSuccess;
	}
	/**
	 * @param webServiceSuccess the webServiceSuccess to set
	 */
	public void setWebServiceSuccess(boolean webServiceSuccess) {
		this.webServiceSuccess = webServiceSuccess;
	}
	/**
	 * @return the restServiceSuccess
	 */
	public boolean isRestServiceSuccess() {
		return restServiceSuccess;
	}
	/**
	 * @param restServiceSuccess the restServiceSuccess to set
	 */
	public void setRestServiceSuccess(boolean restServiceSuccess) {
		this.restServiceSuccess = restServiceSuccess;
	}
	
}
