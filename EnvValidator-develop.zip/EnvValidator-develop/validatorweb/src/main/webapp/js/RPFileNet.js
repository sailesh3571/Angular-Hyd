

/*****************************************************
/ JavaScript file created and edited by Kyle Sullens
/ and Mike Clark. 
/---------------------------------------------------
/  Jul 26, 2005 
//////////////////////////////////////////////////////
*/

			wcBodyClass = "wcFullWidthLayout";
			wcLocalTitle  = "Retirement Plan Document Search";
			wcMastheadType = "extranet";
			
		/*  sLocalTitle = "PlanNet<sup>&reg;</sup>" */		

/***************************************************************
  This function allows the user to select all checkboxes in a 
  group by checking the outer box.  It will also de-select all
  the boxes when the outer box is un-checked.
*****************************************************************/
	function CheckAllCheckBoxes(chkBoxID, cblID) {	
	    var form = document.forms[0]
			 /* Step 1 - find the element on the form that corresponds with
			    the checkbox being evaluated */
			    for (i=0;i< form.elements.length; i++) {
			    
			        if (form.elements[i].name.indexOf(chkBoxID) > -1) {
			          /* We've found our checkbox.  Now go through and find all
			             Checkboxes in the CheckBoxList.  These elements will have a
			             name that contains the string contained in cblID */
			             
			            for (x=0;x< form.elements.length; x++) {					
							
							if (form.elements[x].type == "checkbox" &&
								form.elements[x].id.indexOf(cblID) > -1) {
									form.elements[x].checked = form.elements[i].checked
							}
						  
						}
			        }
			  
			     }
	}
	
	

function ValidateContractSearch() {
    var form = document.forms[0]
 
    if (form.SearchForContract_txtPlanID.value == '' && 
        form.SearchForContract_txtPlanName.value == ''){
              window.alert("Please enter a plan number and/or a plan name.")
     }
     
  }

function ValidateAndPrepareContractSearch(action) {
    var form = document.forms[0]
 
    if (form.SearchForContract_txtPlanID.value == '' && 
        form.SearchForContract_txtPlanName.value == ''){
              window.alert("Please enter a plan number and/or a plan name.")
     }
     form.action = action
     //form.submit()
  }


function ValidatePptSearch(action) {
    var form = document.forms[0]
 
    if (form.SearchForParticipant_txtPptID.value == '' && 
        form.SearchForParticipant_txtPptName.value == ''){
              window.alert("Please enter either a Participant Name and/or a Participant ID")
     }
    form.action = action
  }